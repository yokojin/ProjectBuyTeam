﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{
    static class Human
    {
        public static string FirstName="";
        public static string LastName="";
    }
}
